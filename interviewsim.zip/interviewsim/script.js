const questions = [
    "Why do you want this job even though it pays in compliments?",
    "If you were a vegetable, which one would you be and why?",
    "How would you handle a zombie apocalypse in the office?",
    "What is your greatest weakness? (Wrong answers only)",
    "If we gave you a cat, how would you convince it to work here?"
];

const funnyResponses = [
    "Wow! You're as prepared as a popcorn in a microwave! 🍿",
    "I see you're aiming for the CEO position, huh? 😎",
    "Well, that answer deserves a standing ovation... from ants! 🐜",
    "I'd hire you just to hear more answers like that! 😂",
    "That's an answer Shakespeare would be proud of! 🎭"
];

let currentQuestionIndex = -1;

function startInterview() {
    currentQuestionIndex = Math.floor(Math.random() * questions.length);
    document.getElementById("question").innerText = questions[currentQuestionIndex];
    document.getElementById("questionContainer").classList.remove("hidden");
    document.getElementById("result").classList.add("hidden");
}

function submitAnswer() {
    const answer = document.getElementById("answer").value.trim();
    if (answer === "") {
        alert("Please enter an answer before submitting!");
        return;
    }

    const randomResponseIndex = Math.floor(Math.random() * funnyResponses.length);
    const resultDiv = document.getElementById("result");
    resultDiv.innerText = funnyResponses[randomResponseIndex];
    resultDiv.classList.remove("hidden");
    document.getElementById("answer").value = "";
}
